# Tools

## Scripts

### Find-SqlProcedures

Finds the names of all stored procedures that are executed by given stored procedure.

Example:
```powershell
.\Find-SqlProcedures.ps1 -FolderPath "C:\Database\Stored Procedures" -StoredProcedureName "bsp_BHCreateDepartment"
```

### Find-ItemContent

Finds lines of text inside all files in the given directory.

Example:
```powershell
.\Find-ItemContent.ps1 -LiteralPath "C:\Repo\" -FileFilter "*.csproj"  -RegexPattern "Unity"
```

### Compare-BinFolderContent

Compares source and target bin folder content and outputs added, removed file names and also files that exist in both forders but have different assembly names.

Example:
```powershell
.\Compare-BinFolderContent.ps1 -SourceLiteralPath "C:\Project1\bin\Debug"  -TargetLiteralPath "C:\Project2\bin\Debug"
```

### Get-AssemblyReference

Loads found assemblies using reflection and outputs those that are referencing given assembly of given version.

Example:
```powershell
.\Get-AssemblyReference.ps1 -Path "C:\App\Bin" -ReferenceName "AssemblyName" -ReferenceVersion "1.0.0.0" | Format-List *
```